# FAQ for development

## Introduction

### Integration tests fail

Try to run the command in the console `java -jar ...` and remove `-Dlogging.pattern.console=` from the command line.

